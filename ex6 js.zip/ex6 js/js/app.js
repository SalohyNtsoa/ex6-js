$ (document).ready(function(){
    $(".btn-cal").on("click", function(){
        const val1 = $(value1).val()
        const val2 = $(value2).val()
        $(".resultat").html(parseFloat(val1) + parseFloat(val2))
        
    }
    )
}
)